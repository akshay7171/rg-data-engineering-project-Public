CREATE LOGIN luke WITH PASSWORD = '123456789'

create user luke for login luke